INSERT INTO status (id, name) VALUES
(1, 'new'),
(2, 'sold,'),
(3, 'under-maintenance'),
(4, 'refurbished'),
(5, 'scrap');