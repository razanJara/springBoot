package management.device.enums;

public enum Os {
    ios,
    android,
    windows,
    linux
}
