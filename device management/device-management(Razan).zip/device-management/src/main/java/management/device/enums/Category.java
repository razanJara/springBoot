package management.device.enums;

public enum Category {
    printers,
    smartphones,
    computers
}
