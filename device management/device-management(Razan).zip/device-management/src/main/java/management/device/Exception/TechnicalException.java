package management.device.Exception;

public class TechnicalException extends RuntimeException{
    public TechnicalException (String message){
        super(message);
    }
}
